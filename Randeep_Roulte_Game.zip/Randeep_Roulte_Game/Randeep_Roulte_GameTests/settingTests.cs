﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Randeep_Roulte_Game;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Randeep_Roulte_Game.Tests
{
    [TestClass()]
    public class settingTests
    {
        [TestMethod()]
        public void settingTest()
        {
            setting obj = new setting();
        }
    }
}